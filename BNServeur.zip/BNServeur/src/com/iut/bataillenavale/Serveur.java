package com.iut.bataillenavale;

import java.io.PrintWriter;
import java.util.HashSet;

public class Serveur {
	/**
	 * List des noms des utilisateurs pr�sent sur le chat
	 */
	private static HashSet<String> names = new HashSet<String>();
	/**
	 * Liste de writers pour le broadcast des reponses
	 */
	private static HashSet<PrintWriter> writers = new HashSet<PrintWriter>();

	public static HashSet<String> getNames(){
		return names;
	}
	
	public static HashSet<PrintWriter> getWriters(){
		return writers;
	}
}
