package com.iut.bataillenavale;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;



public class Handler extends Thread  {
	private String name;
	private Socket socket;
	private BufferedReader in;
	private PrintWriter out;

	/**
	 * Creation des Thread "m�tier"
	 */
	public Handler(Socket socket ) {
		this.socket = socket;
	}


	public void run() {
		try {

			//R�cup�ration du flux d'entree / sortie du socket
			in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			out = new PrintWriter(socket.getOutputStream(), true);

			// Demande du nom de client de la nouvelle connexion V�rification des noms deja pr�sent et ajout si celui ci n'�tait pas d�j� co.
			while (true) {
				out.println("SUBMITNAME");
				name = in.readLine();
				if (name == null) {
					return;
				}
				synchronized (Serveur.getNames()) {
					if (!Serveur.getNames().contains(name)) {
						Serveur.getNames().add(name);
						break;
					}
				}
			}

			// R�ponse au clien pour lui dire que le nom est OK
			out.println("NAMEACCEPTED");
			Serveur.getWriters().add(out);

			// On attend les message de cette utilisateur
			while (true) {
				String input = in.readLine();
				if (input == null) {
					return;
				}
				//Si j'ai un messge je le forward a tous les autres utilisateurs
				for (PrintWriter writer : Serveur.getWriters()) {
					writer.println("MESSAGE " + name + ": " + input);
				}
			}
		} catch (IOException e) {
			System.out.println(e);
		} finally {
			//Probl�me avec le socket on le clo et on le remove de la liste des utilisateur connecter
			if (name != null) {
				Serveur.getNames().remove(name);
			}
			if (out != null) {
				Serveur.getWriters().remove(out);
			}
			try {
				socket.close();
			} catch (IOException e) {
			}
		}
	}
}