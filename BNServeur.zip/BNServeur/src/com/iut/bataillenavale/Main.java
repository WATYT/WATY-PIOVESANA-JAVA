package com.iut.bataillenavale;

import java.net.ServerSocket;



public class Main {
	/**
	 * Le port d'�coute du serveur 
	 */
	private static final int PORT = 9001;
	
	public static void main(String[] args) throws Exception {
		System.out.println("Lancement du serveur.");
		ServerSocket listener = new ServerSocket(PORT)	;
		try {
			while (true) {
				new Handler(listener.accept()).start();
			}
		} finally {
			listener.close();
		}
	}
}
